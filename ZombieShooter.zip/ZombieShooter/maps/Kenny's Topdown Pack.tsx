<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Kenny's Topdown Pack" tilewidth="64" tileheight="64" spacing="10" tilecount="540" columns="27">
 <image source="../sprites/mapSprites/spritesheet_tiles.png" width="1988" height="1470"/>
</tileset>
